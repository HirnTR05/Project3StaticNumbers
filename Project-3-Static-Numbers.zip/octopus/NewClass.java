public class NewClass {
}